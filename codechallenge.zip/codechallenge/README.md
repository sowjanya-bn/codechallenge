# CODE Challenge LinkedIn API

## Getting Started

### *Pre-requisites*

Ensure the following are installed:

1. Java Development Kit (JDK) 17 or higher
2. Maven 3.6 or higher


### Run the Application

1. Build and run the service using Maven:
```
   mvn spring-boot:run
```
2. Alternatively, build the JAR file and run it:
```
   mvn clean package
   java -jar target/codechallenge-0.0.1-SNAPSHOT.jar
```

### Accessing the API

#### Swagger UI
After starting the service, open the following URL in your browser to access the Swagger UI:
http://localhost:8080/swagger-ui/index.html

### Configuration

The service can be configured using application.yml in the src/main/resources directory. 
Example:

```<yaml>
server:
  port: 8080

downstream:
  api:
    base-url: http://example.com
```

To override properties at runtime, use system properties:

```
java -jar -Dserver.port=9090 target/codechallenge-0.0.1-SNAPSHOT.jar
```
### Running Tests

Run unit and integration tests using Maven:

```
mvn test

```

### Contact

For further assistance, reach out to:

Name: Naga Sowjanya Barla
Email: nagasowjanya.barla@gmail.com