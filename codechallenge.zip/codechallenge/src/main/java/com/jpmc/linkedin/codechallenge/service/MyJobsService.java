package com.jpmc.linkedin.codechallenge.service;

import static com.jpmc.linkedin.codechallenge.util.RegexPatterns.CSRF_VALUE_PATTERN;
import static com.jpmc.linkedin.codechallenge.util.RegexPatterns.JSESSIONID_PATTERN;

import com.jpmc.linkedin.codechallenge.config.ApiProperties;
import com.jpmc.linkedin.codechallenge.handler.ResponseHandlerFactory;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.JobStateType;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.regex.Matcher;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class MyJobsService {

  private final HttpClient httpClient;

  private final ResponseHandlerFactory responseHandlerFactory;

  private ApiProperties apiProperties;

  public List<Job> fetchJobs(String url, String cookie) {
    String csrfToken = extractCsrfToken(cookie);
    HttpRequest request = buildHttpRequest(cookie, csrfToken, url);
    try {
      HttpResponse<String> response =
          httpClient.send(request, HttpResponse.BodyHandlers.ofString());
      return responseHandlerFactory.process(response);
    } catch (IOException | InterruptedException e) {
      throw new RuntimeException(e);
    }
  }

  public List<Job> fetchJobs(Integer page, JobStateType jobStateType, String cookie) {
    String buildUrl = getBuildUrl(page, jobStateType);
    String csrfToken = extractCsrfToken(cookie);
    HttpRequest request = buildHttpRequest(cookie, csrfToken, buildUrl);
    try {
      HttpResponse<String> response =
          httpClient.send(request, HttpResponse.BodyHandlers.ofString());
      return responseHandlerFactory.process(response);
    } catch (IOException | InterruptedException e) {
      throw new RuntimeException(e);
    }
  }

  private String getBuildUrl(Integer page, JobStateType jobStateType) {
    return apiProperties.getBaseUrl()
        + "?variables=(start:"
        + (page - 1) * 10
        + ",query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List("
        + jobStateType
        + ")))))&queryId="
        + "voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76";
  }

  private HttpRequest buildHttpRequest(String cookie, String csrfToken, String buildUrl) {
    return HttpRequest.newBuilder()
        .uri(URI.create(buildUrl))
        .header("cookie", cookie)
        .header("csrf-token", csrfToken)
        .header("accept", "*/*")
        .method("GET", HttpRequest.BodyPublishers.noBody())
        .build();
  }

  public String extractCsrfToken(String cookie) {
    Matcher matcher = JSESSIONID_PATTERN.matcher(cookie);
    String jsessionId = null;
    if (matcher.find()) {
      jsessionId = matcher.group();
      return extractSessionId(jsessionId);
    }
    return null;
  }

  public String extractSessionId(String sessionIdToken) {
    Matcher matcher = CSRF_VALUE_PATTERN.matcher(sessionIdToken);
    if (matcher.find()) {
      return matcher.group(1);
    }
    return null;
  }
}
