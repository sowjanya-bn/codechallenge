package com.jpmc.linkedin.codechallenge.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@Getter
public class LinkedInException extends RuntimeException {
  private final HttpStatus status;

  public LinkedInException(String message, HttpStatus status) {
    super(message);
    this.status = status;
  }
}
