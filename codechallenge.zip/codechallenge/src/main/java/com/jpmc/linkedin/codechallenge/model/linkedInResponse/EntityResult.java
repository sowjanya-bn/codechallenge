package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import java.util.List;
import lombok.Data;

@Data
public class EntityResult {
  private Title title;
  private Title primarySubtitle;
  private Title secondarySubtitle;
  private List<InsightsResolutionResult> insightsResolutionResults;
}
