package com.jpmc.linkedin.codechallenge.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class Job {
  @JsonProperty("Role")
  private String role;

  @JsonProperty("Company")
  private String company;

  @JsonProperty("Location")
  private String location;

  @JsonProperty("Applied")
  private String applied;
}
