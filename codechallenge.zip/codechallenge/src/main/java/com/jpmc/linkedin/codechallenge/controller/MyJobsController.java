package com.jpmc.linkedin.codechallenge.controller;

import com.jpmc.linkedin.codechallenge.exception.ErrorResponse;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.JobStateType;
import com.jpmc.linkedin.codechallenge.service.MyJobsService;
import com.jpmc.linkedin.codechallenge.validator.ValidCookie;
import com.jpmc.linkedin.codechallenge.validator.ValidUrl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/my-jobs")
@AllArgsConstructor
public class MyJobsController {

  private final MyJobsService myJobsService;

  @Operation(
      summary = "Get my jobs",
      description = "Retrieves a list of jobs for the LinkedIn URL .",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved the list of items",
            content = @Content(mediaType = "application/json")),
        @ApiResponse(
            responseCode = "400",
            description = "Invalid request parameters",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "CSRF check failed",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "No matching data Found",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "401",
            description = "Invalid Cookie",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)))
      })
  @GetMapping
  public List<Job> fetchJobs(
      @RequestParam(name = "page", defaultValue = "1")
          @Min(value = 1, message = "page must be at least {value}.")
          Integer page,
      @RequestParam(name = "jobType", defaultValue = "APPLIED") JobStateType jobStateType,
      @RequestHeader(value = "linkedInCookie")
          @NotNull
          @ValidCookie(value = {"JSESSIONID", "li_at"})
          String linkedInCookie) {
    return myJobsService.fetchJobs(page, jobStateType, linkedInCookie);
  }

  @Operation(
      summary = "Get my jobs",
      description = "Retrieves a list of jobs for the LinkedIn URL .",
      responses = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved the list of items",
            content = @Content(mediaType = "application/json")),
        @ApiResponse(
            responseCode = "400",
            description = "Invalid request parameters",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "CSRF check failed",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "No matching data Found",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "302",
            description = "Invalid Cookie",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)))
      })
  @GetMapping(path = "/url")
  public List<Job> fetchJobs(
      @RequestParam(name = "linkedInUrl")
          @NotNull
          @ValidUrl(
              value = {
                "www.linkedin.com/voyager/api/graphql",
                "SEARCH_MY_ITEMS_JOB_SEEKER",
                "&queryId="
              })
          String linkedInUrl,
      @RequestHeader(value = "linkedInCookie")
          @NotNull
          @ValidCookie(value = {"JSESSIONID", "li_at"})
          String linkedInCookie) {
    return myJobsService.fetchJobs(linkedInUrl, linkedInCookie);
  }
}
