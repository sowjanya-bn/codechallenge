package com.jpmc.linkedin.codechallenge.model;

public enum JobStateType {
  APPLIED,
  ARCHIVED,
  IN_PROGRESS,
  SAVED;
}
