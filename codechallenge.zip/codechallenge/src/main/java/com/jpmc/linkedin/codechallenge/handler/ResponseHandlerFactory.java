package com.jpmc.linkedin.codechallenge.handler;

import com.jpmc.linkedin.codechallenge.model.Job;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ResponseHandlerFactory {
  private List<ResponseHandler> handlers;

  @Autowired private SuccessHandler successHandler;

  @Autowired private DefaultFailureResponseHandler failureResponseHandler;

  @Autowired private RedirectResponseHandler redirectResponseHandler;

  public List<Job> process(HttpResponse<String> response) {
    ResponseHandler responseHandler =
        Stream.of(
                successHandler,
                redirectResponseHandler,
                failureResponseHandler // Has to be last as default failure handler
                )
            .filter(handler -> handler.supports(response))
            .findFirst()
            .orElseThrow(() -> new IllegalStateException("No handler found"));
    return responseHandler.handle(response);
  }
}
