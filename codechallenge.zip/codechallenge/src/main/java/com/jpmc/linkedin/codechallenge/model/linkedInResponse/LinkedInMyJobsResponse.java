package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import java.util.List;

@lombok.Data
public class LinkedInMyJobsResponse {
  private Data data;
  private List<Error> errors;

  public boolean hasErrors() {
    return null != errors && !errors.isEmpty();
  }
}
