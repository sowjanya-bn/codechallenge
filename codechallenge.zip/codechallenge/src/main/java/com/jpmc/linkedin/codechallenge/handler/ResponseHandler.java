package com.jpmc.linkedin.codechallenge.handler;

import com.jpmc.linkedin.codechallenge.model.Job;
import java.net.http.HttpResponse;
import java.util.List;

public interface ResponseHandler {
  boolean supports(HttpResponse<String> response);

  List<Job> handle(HttpResponse<String> response);
}
