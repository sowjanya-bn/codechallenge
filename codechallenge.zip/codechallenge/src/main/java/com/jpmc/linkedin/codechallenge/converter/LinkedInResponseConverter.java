package com.jpmc.linkedin.codechallenge.converter;

import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.linkedInResponse.LinkedInMyJobsResponse;
import java.util.List;

public interface LinkedInResponseConverter {
  List<Job> convert(LinkedInMyJobsResponse response);
}
