package com.jpmc.linkedin.codechallenge.validator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = ValidCookieValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidCookie {
  String message() default "Must contain the specified keys";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  String[] value(); // Substring to be contained
}
