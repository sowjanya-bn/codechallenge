package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import lombok.Data;

@Data
public class SearchItem {
  private Item item;
}
