package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import lombok.Data;

@Data
public class Title {
  private String text;
}
