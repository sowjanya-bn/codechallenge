package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import lombok.Data;

@Data
public class Error {
  private String[] path;
  private String message;
}
