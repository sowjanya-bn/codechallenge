package com.jpmc.linkedin.codechallenge.converter;

import com.jpmc.linkedin.codechallenge.exception.LinkedInException;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.linkedInResponse.*;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class SuccessLinkedInResponseConverter implements LinkedInResponseConverter {
  @Override
  public List<Job> convert(LinkedInMyJobsResponse input) {
    SearchDashClustersByAll searchDashClustersByAll = input.getData().getSearchDashClustersByAll();
    if (searchDashClustersByAll != null) {
      if (null != searchDashClustersByAll.getElements()
          && !searchDashClustersByAll.getElements().isEmpty()) {
        List<Element> elements = searchDashClustersByAll.getElements();
        if (elements.size() == 1) {
          Element element = elements.get(0);
          List<SearchItem> items = element.getItems();
          if (null != items && !items.isEmpty()) {
            return items.stream().map(this::buildJob).toList();
          } else throw new LinkedInException("No matching Data Found", HttpStatus.NOT_FOUND);
        } else
          throw new LinkedInException(
              "Invalid Response, multiple data elements found", HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }
    throw new LinkedInException(
        "Invalid Response, no data found", HttpStatus.INTERNAL_SERVER_ERROR);
  }

  private Job buildJob(SearchItem item) {
    EntityResult entityResult = item.getItem().getEntityResult();
    return Job.builder()
        .role((null != entityResult.getTitle()) ? entityResult.getTitle().getText() : null)
        .company(
            (null != entityResult.getPrimarySubtitle())
                ? entityResult.getPrimarySubtitle().getText()
                : null)
        .location(
            (null != entityResult.getSecondarySubtitle())
                ? entityResult.getSecondarySubtitle().getText()
                : null)
        .applied(
            (null != entityResult.getInsightsResolutionResults())
                ? entityResult
                    .getInsightsResolutionResults()
                    .get(0)
                    .getSimpleInsight()
                    .getTitle()
                    .getText()
                : null)
        .build();
  }
}
