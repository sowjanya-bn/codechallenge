package com.jpmc.linkedin.codechallenge.handler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.linkedin.codechallenge.converter.ErrorLinkedInResponseConverter;
import com.jpmc.linkedin.codechallenge.converter.SuccessLinkedInResponseConverter;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.linkedInResponse.LinkedInMyJobsResponse;
import java.net.http.HttpResponse;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class SuccessHandler implements ResponseHandler {

  private final ObjectMapper objectMapper;

  private final SuccessLinkedInResponseConverter successLinkedInResponseConverter;

  private final ErrorLinkedInResponseConverter errorLinkedInResponseConverter;

  @Override
  public boolean supports(HttpResponse<String> response) {
    return response.statusCode() == 200;
  }

  @Override
  public List<Job> handle(HttpResponse<String> response) {
    try {
      LinkedInMyJobsResponse linkedInMyJobsResponse =
          objectMapper.readValue(response.body(), LinkedInMyJobsResponse.class);
      if (linkedInMyJobsResponse.hasErrors())
        return errorLinkedInResponseConverter.convert(linkedInMyJobsResponse);
      else return successLinkedInResponseConverter.convert(linkedInMyJobsResponse);
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
  }
}
