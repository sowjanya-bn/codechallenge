package com.jpmc.linkedin.codechallenge.exception;

import java.time.Instant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {
  private Instant timestamp;
  private HttpStatus status;
  private String message;
  private String path;
}
