package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import lombok.Data;

@Data
public class SimpleInsight {
  private Title title;
}
