package com.jpmc.linkedin.codechallenge.converter;

import com.jpmc.linkedin.codechallenge.exception.LinkedInException;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.linkedInResponse.Error;
import com.jpmc.linkedin.codechallenge.model.linkedInResponse.LinkedInMyJobsResponse;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class ErrorLinkedInResponseConverter implements LinkedInResponseConverter {
  @Override
  public List<Job> convert(LinkedInMyJobsResponse input) {
    throw new LinkedInException(
        input.getErrors().stream().map(Error::getMessage).collect(Collectors.joining(";")),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
