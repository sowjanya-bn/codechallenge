package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

@lombok.Data
public class Data {
  private SearchDashClustersByAll searchDashClustersByAll;
}
