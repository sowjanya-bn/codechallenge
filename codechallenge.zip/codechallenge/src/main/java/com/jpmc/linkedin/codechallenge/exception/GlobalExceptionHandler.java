package com.jpmc.linkedin.codechallenge.exception;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.method.ParameterValidationResult;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
public class GlobalExceptionHandler {

  @PostConstruct
  public void init() {
    // Initialization logic here
    System.out.println("Initializing GlobalExceptionHandler...");
  }

  @ExceptionHandler(LinkedInException.class)
  public ResponseEntity<ErrorResponse> handleLinkedInException(
      LinkedInException ex, HttpServletRequest request) {
    return new ResponseEntity<>(
        new ErrorResponse(Instant.now(), ex.getStatus(), ex.getMessage(), request.getRequestURI()),
        ex.getStatus());
  }

  @ExceptionHandler(MissingRequestHeaderException.class)
  public ResponseEntity<ErrorResponse> handleMissingRequestHeaderException(
      MissingRequestHeaderException ex, HttpServletRequest request) {
    return new ResponseEntity<>(
        new ErrorResponse(
            Instant.now(), HttpStatus.BAD_REQUEST, ex.getMessage(), request.getRequestURI()),
        HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(MissingServletRequestParameterException.class)
  public ResponseEntity<ErrorResponse> handleMissingServletRequestParameterException(
      MissingServletRequestParameterException ex, HttpServletRequest request) {
    return new ResponseEntity<>(
        new ErrorResponse(
            Instant.now(), HttpStatus.BAD_REQUEST, ex.getMessage(), request.getRequestURI()),
        HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  public ResponseEntity<ErrorResponse> handleMethodArgumentTypeMismatchException(
      MethodArgumentTypeMismatchException ex, HttpServletRequest request) {
    return new ResponseEntity<>(
        new ErrorResponse(
            Instant.now(), HttpStatus.BAD_REQUEST, ex.getMessage(), request.getRequestURI()),
        HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> handleGeneralException(
      Exception ex, HttpServletRequest request) {
    return new ResponseEntity<>(
        new ErrorResponse(
            Instant.now(),
            HttpStatus.INTERNAL_SERVER_ERROR,
            ex.getMessage(),
            request.getRequestURI()),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler(HandlerMethodValidationException.class)
  public ResponseEntity<Object> handleHandlerMethodValidationException(
      HandlerMethodValidationException ex, HttpServletRequest request) {

    List<ParameterValidationResult> parameterValidationResults = ex.getParameterValidationResults();

    List<String> errorMessages =
        parameterValidationResults.stream()
            .map(
                parameterValidationResult -> {
                  List<MessageSourceResolvable> messageSourceResolvables =
                      parameterValidationResult.getResolvableErrors();

                  if (!messageSourceResolvables.isEmpty())
                    return messageSourceResolvables.stream()
                        .map(messageSourceResolvable -> messageSourceResolvable.getDefaultMessage())
                        .collect(Collectors.joining(","));
                  else return "";
                })
            .collect(Collectors.toList());

    // You can customize the response here (e.g., error codes, timestamps, etc.)
    return new ResponseEntity<>(
        new ErrorResponse(
            Instant.now(),
            HttpStatus.BAD_REQUEST,
            String.join(";", errorMessages),
            request.getRequestURI()),
        HttpStatus.BAD_REQUEST);
  }
}
