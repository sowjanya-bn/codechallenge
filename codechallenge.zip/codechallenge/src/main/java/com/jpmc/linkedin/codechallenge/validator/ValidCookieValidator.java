package com.jpmc.linkedin.codechallenge.validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Arrays;

public class ValidCookieValidator implements ConstraintValidator<ValidCookie, String> {

  private String[] match;

  @Override
  public void initialize(ValidCookie constraintAnnotation) {
    this.match = constraintAnnotation.value();
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    }

    boolean result = Arrays.stream(match).allMatch(value::contains);

    if (!result) {
      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(
              "The cookie must contain all of the keys: '" + String.join("','", match) + "'")
          .addConstraintViolation();
    }
    return result;
  }
}
