package com.jpmc.linkedin.codechallenge.validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Arrays;

public class ValidUrlValidator implements ConstraintValidator<ValidUrl, String> {

  private String[] match;

  @Override
  public void initialize(ValidUrl constraintAnnotation) {
    this.match = constraintAnnotation.value();
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    }

    boolean result = Arrays.stream(match).allMatch(value::contains);

    if (!result) {
      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(
              "The url must contain all of: '" + String.join("','", match) + "'")
          .addConstraintViolation();
    }
    return result;
  }
}
