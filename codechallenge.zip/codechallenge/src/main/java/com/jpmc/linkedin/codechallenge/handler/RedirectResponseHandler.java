package com.jpmc.linkedin.codechallenge.handler;

import com.jpmc.linkedin.codechallenge.exception.LinkedInException;
import com.jpmc.linkedin.codechallenge.model.Job;
import java.net.http.HttpResponse;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class RedirectResponseHandler implements ResponseHandler {
  @Override
  public boolean supports(HttpResponse<String> response) {
    return response.statusCode() == 302;
  }

  @Override
  public List<Job> handle(HttpResponse<String> response) {
    throw new LinkedInException("Request redirected: Invalid Cookie", HttpStatus.UNAUTHORIZED);
  }
}
