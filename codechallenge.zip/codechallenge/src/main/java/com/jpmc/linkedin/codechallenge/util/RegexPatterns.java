package com.jpmc.linkedin.codechallenge.util;

import java.util.regex.Pattern;

public class RegexPatterns {
  public static final Pattern JSESSIONID_PATTERN = Pattern.compile("JSESSIONID=.*?;");
  public static final Pattern CSRF_VALUE_PATTERN = Pattern.compile("JSESSIONID=\"([^\"]+)\";");
}
