package com.jpmc.linkedin.codechallenge.model.linkedInResponse;

import java.util.List;
import lombok.Data;

@Data
public class Element {
  private List<SearchItem> items;
}
