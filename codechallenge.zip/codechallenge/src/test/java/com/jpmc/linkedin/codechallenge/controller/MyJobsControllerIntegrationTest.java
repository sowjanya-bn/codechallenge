package com.jpmc.linkedin.codechallenge.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class MyJobsControllerIntegrationTest {

  private static ClientAndServer mockServer;

  @Autowired private MockMvc mockMvc;

  @BeforeAll
  static void startMockServer() {
    mockServer = startClientAndServer(1080);
  }

  @AfterAll
  static void stopMockServer() {
    mockServer.stop();
  }

  @Test
  void fetchData_success() throws Exception {

    String mockResponseBody = readFile("src/test/resources/successResponse.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    mockMvc
        .perform(get("/my-jobs").header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty())
        .andExpect(jsonPath("$").value(hasSize(10)));
  }

  @Test
  @Disabled
  // Need the valid token for this
  void fetchDataWithUrl_success() throws Exception {

    String mockResponseBody = readFile("src/test/resources/successResponse.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/voyager/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76")
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty())
        .andExpect(jsonPath("$").value(hasSize(10)));
  }

  @Test
  void fetchDataWithInvalidCookie() throws Exception {

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(302));

    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/voyager/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76")
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().is4xxClientError())
        .andExpect(jsonPath("$.message").value("Request redirected: Invalid Cookie"));
  }

  private String readFile(String path) throws IOException {
    return new String(Files.readAllBytes(Paths.get(path)));
  }
}
