package com.jpmc.linkedin.codechallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeChallengeApplicationTests {

  @Test
  void contextLoads() {}
}
