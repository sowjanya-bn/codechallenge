package com.jpmc.linkedin.codechallenge.service;

import static io.swagger.v3.parser.reference.ReferenceUtils.readFile;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

import com.jpmc.linkedin.codechallenge.exception.LinkedInException;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.JobStateType;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class MyJobsServiceTest {

  private ClientAndServer mockServer;

  @Autowired private MyJobsService myJobsService;

  @BeforeEach
  public void setup() {
    mockServer = ClientAndServer.startClientAndServer(1080);
  }

  @Test
  public void testFetchJobsSuccess() throws Exception {

    String mockResponseBody = readFile("src/test/resources/successResponse.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    List<Job> response =
        myJobsService.fetchJobs(
            2,
            JobStateType.APPLIED,
            "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");

    assertNotNull(response);
    assertEquals(10, response.size(), "List size should be 10");
    assertThat(
        response,
        everyItem(
            allOf(
                hasProperty("role", notNullValue()),
                hasProperty("company", notNullValue()),
                hasProperty("location", notNullValue()),
                hasProperty("applied", notNullValue()))));
  }

  @Test
  public void testFetchJobsNoDataFound() throws Exception {

    String mockResponseBody = readFile("src/test/resources/noDataFound.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          2,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals("No matching Data Found", exception.getMessage());
    }
  }

  @Test
  public void testFetchJobsInvalidStartValue() throws Exception {

    String mockResponseBody = readFile("src/test/resources/invalidStartValue.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          0,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals("start/count parameters must be non-negative", exception.getMessage());
    }
  }

  @Test
  public void testFetchJobsMultipleDataElementsFound() throws Exception {

    String mockResponseBody = readFile("src/test/resources/multipleDataElementsFound.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          0,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals("Invalid Response, multiple data elements found", exception.getMessage());
    }
  }

  @Test
  public void testFetchJobsInvalidSuccessWithNoData() throws Exception {

    String mockResponseBody = readFile("src/test/resources/invalidSuccessWithNoData.json");

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(200).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          0,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals("Invalid Response, no data found", exception.getMessage());
    }
  }

  @Test
  public void testFetchJobsNoAuthInCookie() throws Exception {

    String mockResponseBody = "{\n" + "  \"status\" : 401\n" + "}";

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(401).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          0,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals(HttpStatus.UNAUTHORIZED, exception.getStatus());
    }
  }

  @Test
  public void testFetchJobsNoCsrfToken() throws Exception {

    String mockResponseBody = "CSRF check failed.";

    mockServer
        .when(HttpRequest.request().withMethod("GET").withPath("/graphql"))
        .respond(HttpResponse.response().withStatusCode(403).withBody(mockResponseBody));

    try {
      myJobsService.fetchJobs(
          0,
          JobStateType.APPLIED,
          "bcookie=\"v=2&342bf105-33f3-4afb-889c-40fd3b80a944\"; bscookie=\"v=1&20211211121906b1a3b38e-40c1-4361-8801-b4b2ace39a8cAQHyTVAMIa32qxNrgcVf4Rp76snDO2Qw\"; JSESSIONID=\"ajax:6480386528806448175\"; li_theme=light; li_theme_set=app;");
      fail("Expected LinkedInException to be thrown");
    } catch (LinkedInException exception) {
      assertEquals(HttpStatus.FORBIDDEN, exception.getStatus());
    }
  }

  @AfterEach
  public void tearDown() {
    mockServer.stop();
  }
}
