package com.jpmc.linkedin.codechallenge.controller;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.linkedin.codechallenge.model.Job;
import com.jpmc.linkedin.codechallenge.model.JobStateType;
import com.jpmc.linkedin.codechallenge.service.MyJobsService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(MyJobsController.class)
public class MyJobsControllerUnitTest {

  @Autowired private MockMvc mockMvc;

  @MockitoBean private MyJobsService myJobsService;

  @Autowired private ObjectMapper objectMapper;

  @Test
  public void testFetchMyJobs() throws Exception {
    when(myJobsService.fetchJobs(any(), any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(
            get("/my-jobs")
                .param("page", "1")
                .param("jobType", JobStateType.APPLIED.name())
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isOk())
        .andExpect(content().contentType("application/json"))
        .andExpect(jsonPath("$", is(not(empty()))));
  }

  @Test
  public void testFetchMyJobsWithoutCookie() throws Exception {
    mockMvc
        .perform(get("/my-jobs").param("page", "1").param("jobType", JobStateType.APPLIED.name()))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath("$.message")
                .value(
                    "Required request header 'linkedInCookie' for method parameter type String is not present"));
  }

  @Test
  public void testFetchMyJobsWithInvalidPage() throws Exception {
    mockMvc
        .perform(
            get("/my-jobs")
                .param("page", "0")
                .param("jobType", JobStateType.APPLIED.name())
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.message").value("page must be at least 1."));
  }

  @Test
  public void testFetchMyJobsWithInvalidJobType() throws Exception {
    mockMvc
        .perform(
            get("/my-jobs")
                .param("page", "0")
                .param("jobType", "INVALID")
                .header("linkedInCookie", "234234"))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath(
                "$.message",
                containsString(
                    "Method parameter 'jobType': Failed to convert value of type 'java.lang.String' to required type")));
  }

  @Test
  public void testFetchMyJobsWithURL() throws Exception {
    when(myJobsService.fetchJobs(any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/voyager/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76")
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$", is(not(empty()))));
  }

  @Test
  public void testFetchMyJobsWithURLWithoutCookie() throws Exception {
    when(myJobsService.fetchJobs(any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/voyager/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76"))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath("$.message")
                .value(
                    "Required request header 'linkedInCookie' for method parameter type String is not present"));
  }

  @Test
  public void testFetchMyJobsWithURLWithoutURL() throws Exception {
    when(myJobsService.fetchJobs(any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(get("/my-jobs/url").header("linkedInCookie", "234234"))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath("$.message")
                .value(
                    "Required request parameter 'linkedInUrl' for method parameter type String is not present"));
  }

  @Test
  public void testFetchMyJobsWithURLWithInvalidURL() throws Exception {
    when(myJobsService.fetchJobs(any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76")
                .header("linkedInCookie", "JSESSIONID=\"sessionId\"; li_at=test;"))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath("$.message")
                .value(
                    "The url must contain all of: 'www.linkedin.com/voyager/api/graphql','SEARCH_MY_ITEMS_JOB_SEEKER','&queryId='"));
  }

  @Test
  public void testFetchMyJobsWithURLWithInvalidCookie() throws Exception {
    when(myJobsService.fetchJobs(any(), any())).thenReturn(List.of(Job.builder().build()));
    mockMvc
        .perform(
            get("/my-jobs/url")
                .param(
                    "linkedInUrl",
                    "https://www.linkedin.com/voyager/api/graphql?variables=(start:0,query:(flagshipSearchIntent:SEARCH_MY_ITEMS_JOB_SEEKER,queryParameters:List((key:cardType,value:List(APPLIED)))))&queryId=voyagerSearchDashClusters.8832876bc08b96972d2c68331a27ba76")
                .header("linkedInCookie", "234234"))
        .andExpect(status().isBadRequest())
        .andExpect(
            jsonPath("$.message")
                .value("The cookie must contain all of the keys: 'JSESSIONID','li_at'"));
  }
}
